   // Author: Tuneer Saha
   //Date of Creation: 8/11/2018
import java.util.Scanner;
 class Calculator
{
/* 
**********************************************
How to do:
First enter ur choice (1,2,3,4,5,6)
1 is for precise quotient
2 is for quotient and remainder 
3 is for factorial
4 is for sum
5 is for difference
6 is for product
7 is for Finding HCF
8 is for Finding the no. of solution in a quadratic equation.
9 is for Checking prime no. 
10 is for finding square root of a no.
After that in the next line write the dividend and then in the next line divisor (This is only for 1 and 2) 
Same goes with 4,5,6 and 7.
Click submit.
CASE 8
This is yet another special case for finding the NO. OF SOLUTIONS of a quadratic equation.
First enter 8 then the value of a,then the value of b and then the value of c. 
Click submit.
Case 9
This case is for checking if the input is prime no. or not.
For 3 you have to first enter the choice and then in the next line write the no. of which you want to find the factorial and then click submit.
Also dont give a large no. in the factorial finder...try to keep the input less than 40 otherwise it would give output as 0.
Hope u get it :-) 
**********************************************
*/ 
//v0.1 Fixed bug. 
//v0.2 Added Precision Quotient.
//v0.21 Added a Factor finding method. 
//v0.22 Fixed a small bug in the Factor finding method 
//v0.3 Added Factorial finder from my earlier program 
//v0.31 Fixed bug. 
//v0.32 Fixed another bug. 
//v0.33 Added Instructions.
//v0.34 Updated Instructions. 
//v0.4 Added Addition Subtraction and Multiplication
//v0.41 Updated Instructions.
//v0.42 Added HCF Finder. Thanks to Serena Yvonne. 
//v0.43 Updated instructions. 
//v0.5 Added Quadratic equation- no. of solution finder. 
//v0.51 Updated Instructions.
//v0.52 Added Prime no. checker
//v0.53 Fixed bug. 
//v0.54 Added square root finder. 
//v0.55 Updated Instructions. 
//v1 Modified programme for PC compatibility.
//v1.01 Fixed Bug.
//v1.10 Created a PC Interface.
//v1.11 Added Factor finder.
//v1.12 Fixed bug.
    public static void main(String args []) { 
    Scanner sc=new Scanner(System.in);
System.out.println("Enter choice");
System.out.println("1 is for precise quotient");
System.out.println("2 is for quotient and remainder"); 
System.out.println("3 is for factorial");
System.out.println("4 is for sum");
System.out.println("5 is for difference");
System.out.println("6 is for product");
System.out.println("7 is for Finding HCF");
System.out.println("8 is for Finding the no. of solution in a quadratic equation.");
System.out.println("9 is for Checking prime no."); 
System.out.println("10 is for finding square root of a no.");
System.out.println("11 is for finding factors of a no."); 
System.out.println("12 is for finding x and y in linear equation of two variables.");
     int i;
     i=sc.nextInt();
     switch (i) {
        case 1:
         double e,g,f;
		 System.out.println("Enter dividend");
 e=sc.nextInt();
 System.out.println("Enter divisor");
 f=sc.nextInt();
 g=e/f;
 System.out.println("Precise quotient = "+g);  
        break;
        case 2:
        int a,b,c,d;
		System.out.println("Enter dividend");
        a=sc.nextInt();
		System.out.println("Enter divisor");
        b=sc.nextInt();
        c=a/b;
        d=a%b;
        if (d==0){
           System.out.println(b+" is a factor of "+a); 
        }
        else { 
           System.out.println(b+" is not a factor of "+a); 
        }
        System.out.println ("The quotient is "+c);
        System.out.println ("The remainder is "+d);
break;
        case 3:
          long input,output,z;
		  System.out.println("Enter number");
 input=sc.nextInt();
 output=1;
 for(z=input;z>=1;z--) 
 {
    output=output*z; 
 }
 System.out.println("The factorial is " +output);
 break;  
  case 4: 
  long k,l,m;
  System.out.println("Enter first no.");
  k= sc.nextInt();
  System.out.println("Enter second no.");
  l=sc.nextInt();
  m=k+l;
  System.out.println("The sum is "+m);
  break;
  case 5:
  long o,p,q;
  System.out.println("Enter no. FROM which you want to subtract");
  o=sc.nextInt();
  System.out.println("Enter no. WHICH you want to subtract");
  p=sc.nextInt();
  q= o-p;
  System.out.println("The difference is "+q);
  break;
  case 6:
  long r,t,u;
  System.out.println("Enter first no.");
  r=sc.nextInt();
  System.out.println("Enter second no.");
  t=sc.nextInt();
  u=r*t;
  System.out.println("The product is "+u);
  break;
  case 7:
  System.out.println("Enter first no.");
   int n1=sc.nextInt();
   System.out.println("Enter second no.");
   int n2=sc.nextInt();      
   int hcf=0;
   int min = Math.min(n1,n2);
   for(int v=min; v >= 1; v--){
   if(n1%v == 0 && n2%v == 0){
          hcf = v;
break;		  
                    }
           }        
                System.out.print("\nThe hcf of "+n1+" and "+n2+" = "+hcf);
  break;
    case 8:
    System.out.println("The equation is: ax^2 + bx + c = 0");
        System.out.println("Enter a: ");
        int num1 = sc.nextInt();
        System.out.println("a = " + num1);

        System.out.println("Enter b: ");
        int num2 = sc.nextInt();
        System.out.println("b = " + num2);

        System.out.println("Enter c: ");
        int num3 = sc.nextInt();
        System.out.println("c = " + num3);

        int solution = ((num2*num2)-((4*num1)*num3));
        if (solution == 0) {
            System.out.println("The equation has one solution.");
        } else if (solution > 0) {
            System.out.println("The equation has two solutions.");
        } else {
            System.out.println("The equation has no solution.");
        }
   break;
   case 9:
    long num,zx,count=0;
       
       System.out.println("Enter the number you want to check");
       num=sc.nextInt();
       
        for(zx=2;zx<num;zx++)
        
        {
           if(num%zx==0) 
            {
    
               count++;
            }
            
             
        }
        
        
       if(count>1)
       {
          System.out.println(num+" is not a prime no.") ;
       }
       
      else
      {
         System.out.println(num+" is a prime no.") ;
      } 
      break;
      
      case 10:
      System.out.println("Enter the number");
      long opp = sc.nextInt();
        double det = Math.sqrt(opp);
        System.out.println("The square root of "+opp+" is "+det);
        break;
case 11:
System.out.println("Enter no.");
long factor=sc.nextInt();
System.out.println("Generating factors...");
long cv=0;
for (cv=1;cv<=factor;cv++)
{
if(factor%cv==0)
System.out.println(cv);
}
break;	
case 12:
long a1,a2,b1,b2,c1,c2,num8,num9;
System.out.println("The equation should be in form a1x+b1y+c1 and a2x+b2y+c2");
System.out.println("Enter a1");
a1=sc.nextInt();
System.out.println("Enter b1");
b1=sc.nextInt();
System.out.println("Enter c1");
c1=sc.nextInt();
System.out.println("Enter a2");
a2=sc.nextInt();
System.out.println("Enter b2");
b2=sc.nextInt();
System.out.println("Enter c2");
c2=sc.nextInt();
System.out.println("***********Solution*************");
num8=((b1*c2)-(b2*c1))/((a1*b2)-(a2*b1));
num9=((c1*a2)-(c2*a1))/((a1*b2)-(a2*b1));
System.out.println("The value of x is: "+num8);
System.out.println("The value of y is: "+num9);
System.out.println("********************************");
break;
      
        default:
        System.out.println("Error");
         
     }
        
    }
}
